So if the malware does not need any command line argument, then you should just run 

run_dump.sh malware_executable time_to_wait_b4_dumping


If the malware needs a commandline argument, then run

run_malware.sh malware_executable commandline_argument
dump.sh time_to_wait_b4_dumping
