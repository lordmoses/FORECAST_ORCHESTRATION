#scp -r moses@192.168.56.101:~/* .
rsync -avz --exclude 'transfer*' moses@192.168.56.101:~/from_windbg /home/moses/forsee/forsee/from_win7/from_windbg
