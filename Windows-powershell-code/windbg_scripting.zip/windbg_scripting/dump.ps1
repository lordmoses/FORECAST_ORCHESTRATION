\
wi  ndbg -c ".dump /ma C:\Users\moses\Documents\from_windbg\test\temp.dmp; q" -pn $args -logo C:\Users\moses\Documents\from_windbg\test\dump-$args.log





