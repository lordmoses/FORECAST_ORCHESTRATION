#scp -r /home/moses/forsee/forsee/from_win7/* moses@192.168.56.101:~
rsync -avz --delete /home/moses/forsee/forsee/from_win7/*  moses@192.168.56.101:~
