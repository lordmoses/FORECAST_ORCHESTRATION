stop-process -name windbg

