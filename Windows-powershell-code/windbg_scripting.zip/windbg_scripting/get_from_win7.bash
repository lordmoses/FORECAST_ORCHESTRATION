scp moses@192.168.56.101:~/*.sh .
scp moses@192.168.56.101:~/*.ps1 .
